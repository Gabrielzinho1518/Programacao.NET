using System;

class Livro
{
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public int Ano { get; set; }
    public bool Emprestado { get; private set; } 
    
    public Livro(string titulo, string autor, int ano)
    {
        Titulo = titulo;
        Autor = autor;
        Ano = ano;
        Emprestado = false; 
    }

    public void Emprestar()
    {
        if (!Emprestado)
        {
            Emprestado = true;
            Console.WriteLine($"O livro \"{Titulo}\" foi emprestado.");
        }
        else
        {
            Console.WriteLine($"O livro \"{Titulo}\" já está emprestado.");
        }
    }

    public void Devolver()
    {
        if (Emprestado)
        {
            Emprestado = false;
            Console.WriteLine($"O livro \"{Titulo}\" foi devolvido.");
        }
        else
        {
            Console.WriteLine($"O livro \"{Titulo}\" já está disponível.");
        }
    }

    public void ExibirDados()
    {
        Console.WriteLine($"\nTítulo: {Titulo}");
        Console.WriteLine($"Autor: {Autor}");
        Console.WriteLine($"Ano: {Ano}");
        Console.WriteLine($"Emprestado: {(Emprestado ? "Sim" : "Não")}");
    }

    static void Main()
    {
        Livro[] livros = new Livro[2];

        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine($"\nCadastro do Livro {i + 1}:");

            Console.Write("Título: ");
            string titulo = Console.ReadLine();

            Console.Write("Autor: ");
            string autor = Console.ReadLine();

            Console.Write("Ano: ");
            int ano = int.Parse(Console.ReadLine());

            livros[i] = new Livro(titulo, autor, ano);
        }

        foreach (var livro in livros)
        {
            livro.ExibirDados();
        }

        livros[0].Emprestar();
        livros[0].ExibirDados();
        livros[0].Devolver();
        livros[0].ExibirDados();
    }
}
