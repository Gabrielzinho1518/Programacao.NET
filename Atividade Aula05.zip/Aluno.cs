using System;

class Aluno
{
    public string Nome { get; set; }
    public int Idade { get; set; }
    public string Curso { get; set; }
    public string Matricula { get; set; }

    public Aluno(string nome, int idade, string curso, string matricula)
    {
        Nome = nome;
        Idade = idade;
        Curso = curso;
        Matricula = matricula;
    }

    public void ExibirDados()
    {
        Console.WriteLine("\nDados do Aluno:");
        Console.WriteLine($"Nome: {Nome}");
        Console.WriteLine($"Idade: {Idade}");
        Console.WriteLine($"Curso: {Curso}");
        Console.WriteLine($"Matrícula: {Matricula}");
    }

    static void Main()
    {
        Console.Write("Digite o nome do aluno: ");
        string nome = Console.ReadLine();

        Console.Write("Digite a idade: ");
        int idade = int.Parse(Console.ReadLine());

        Console.Write("Digite o curso: ");
        string curso = Console.ReadLine();

        Console.Write("Digite a matrícula: ");
        string matricula = Console.ReadLine();

        Aluno aluno = new Aluno(nome, idade, curso, matricula);
        aluno.ExibirDados();
    }
}
