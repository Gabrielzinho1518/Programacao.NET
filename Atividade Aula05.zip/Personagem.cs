import java.util.Scanner;

class Personagem {
    // Atributos
    private String nome;
    private String posicao;
    private String itensColetados;

    // Construtor
    public Personagem(String nome, String posicao, String itens) {
        this.nome = nome;
        this.posicao = posicao;
        this.itensColetados = itens;
    }

    // Método para atacar
    public void atacar(double dano) {
        if (dano < 0 || dano > 10) {
            System.out.println("Dano inválido! Use um valor entre 0 e 10.");
            return;
        }
        System.out.println(nome + " atacou com " + dano + " de dano!");
    }

    // Método para movimentar
    public void movimentar(int direcao) {
        String movimento;
        switch (direcao) {
            case 1: movimento = "para frente"; break;
            case 2: movimento = "para trás"; break;
            case 3: movimento = "para a direita"; break;
            case 4: movimento = "para a esquerda"; break;
            default: movimento = "movimento inválido"; break;
        }
        System.out.println(nome + " se moveu " + movimento + ".");
    }

    // Método para exibir dados do personagem
    public void exibirDados() {
        System.out.println("\nNome: " + nome);
        System.out.println("Posição: " + posicao);
        System.out.println("Itens Coletados: " + itensColetados);
    }

    // Programa principal
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leitura dos dados pelo teclado
        System.out.print("Digite o nome do personagem: ");
        String nome = scanner.nextLine();

        System.out.print("Digite a posição inicial: ");
        String posicao = scanner.nextLine();

        System.out.print("Itens coletados (separados por vírgula): ");
        String itens = scanner.nextLine();

        // Criar o personagem
        Personagem p = new Personagem(nome, posicao, itens);
        
        // Exibir os dados
        p.exibirDados();

        // Testar ações
        System.out.print("\nDigite o dano do ataque (0 a 10): ");
        double dano = scanner.nextDouble();
        p.atacar(dano);

        System.out.print("\nDigite a direção para movimentar (1 - frente, 2 - trás, 3 - direita, 4 - esquerda): ");
        int direcao = scanner.nextInt();
        p.movimentar(direcao);

        scanner.close();
    }
}
