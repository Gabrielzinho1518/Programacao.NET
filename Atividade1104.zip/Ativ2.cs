﻿namespace Atividade2;

using System;

abstract class Veiculo
{
    public string Marca { get; set; }
    public string Modelo { get; set; }

    public Veiculo(string marca, string modelo)
    {
        Marca = marca;
        Modelo = modelo;
    }

    // Método abstrato
    public abstract void Dirigir();
}

class Carro : Veiculo
{
    public int NumeroDePortas { get; set; }

    public Carro(string marca, string modelo, int numeroDePortas)
        : base(marca, modelo)
    {
        NumeroDePortas = numeroDePortas;
    }

    public override void Dirigir()
    {
        Console.WriteLine($"Dirigindo o {Marca} {Modelo} com {NumeroDePortas} portas.");
    }
}

class Moto : Veiculo
{
    public int Cilindrada { get; set; }

    public Moto(string marca, string modelo, int cilindrada)
        : base(marca, modelo)
    {
        Cilindrada = cilindrada;
    }

    public override void Dirigir()
    {
        Console.WriteLine($"Dirigindo a {Marca} {Modelo} com {Cilindrada} cilindradas.");
    }
}

// Exemplo de uso
class Program
{
    static void Main()
    {
        Carro carro = new Carro("Toyota","Supra", 3);
        carro.Dirigir();

        Moto moto = new Moto("Honda", "BIS", 200);
        moto.Dirigir();
    }
}
