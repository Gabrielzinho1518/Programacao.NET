﻿namespace Atividade3
{
    using System;

    // Classe abstrata base
    abstract class ContaBancaria
    {
        public decimal Saldo { get; protected set; }

        public ContaBancaria(decimal saldoInicial)
        {
            Saldo = saldoInicial;
        }

        public abstract void Depositar(decimal valor);
        public abstract void Sacar(decimal valor);
    }

    // Conta Corrente - permite saque com limite
    class ContaCorrente : ContaBancaria
    {
        public decimal Limite { get; set; }

        public ContaCorrente(decimal saldoInicial, decimal limite)
            : base(saldoInicial)
        {
            Limite = limite;
        }

        public override void Depositar(decimal valor)
        {
            if (valor > 0)
            {
                Saldo += valor;
                Console.WriteLine($"Depósito de R${valor} realizado. Saldo atual: R${Saldo}");
            }
            else
            {
                Console.WriteLine("Valor de depósito inválido.");
            }
        }

        public override void Sacar(decimal valor)
        {
            if (valor > 0 && Saldo + Limite >= valor)
            {
                Saldo -= valor;
                Console.WriteLine($"Saque de R${valor} realizado. Saldo atual: R${Saldo}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para saque.");
            }
        }
    }

    // Conta Poupança - não permite saldo negativo
    class ContaPoupanca : ContaBancaria
    {
        public ContaPoupanca(decimal saldoInicial)
            : base(saldoInicial)
        {
        }

        public override void Depositar(decimal valor)
        {
            if (valor > 0)
            {
                Saldo += valor;
                Console.WriteLine($"Depósito de R${valor} realizado. Saldo atual: R${Saldo}");
            }
            else
            {
                Console.WriteLine("Valor de depósito inválido.");
            }
        }

        public override void Sacar(decimal valor)
        {
            if (valor > 0 && Saldo >= valor)
            {
                Saldo -= valor;
                Console.WriteLine($"Saque de R${valor} realizado. Saldo atual: R${Saldo}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para saque.");
            }
        }
    }

    // Exemplo de uso
    class Program
    {
        static void Main()
        {
            ContaCorrente cc = new ContaCorrente(4000, 400); 
            cc.Depositar(500);
            cc.Sacar(1500);  
            cc.Sacar(300); 

            Console.WriteLine();

            ContaPoupanca cp = new ContaPoupanca(800);
            cp.Depositar(100);
            cp.Sacar(1000);   
            cp.Sacar(100);  
        }
    }
}