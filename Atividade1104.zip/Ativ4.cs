﻿namespace Atividade4
{
    using System;

    // Classe abstrata base
    abstract class Produto
    {
        public string Nome { get; set; }
        public decimal Preco { get; set; }

        public Produto(string nome, decimal preco)
        {
            Nome = nome;
            Preco = preco;
        }

        // Método abstrato para calcular o desconto
        public abstract decimal CalcularDesconto();
    }

    // Classe derivada - Livro
    class Livro : Produto
    {
        public Livro(string nome, decimal preco)
            : base(nome, preco)
        {
        }

        public override decimal CalcularDesconto()
        {
            decimal desconto = Preco * 0.05m;  // 5% de desconto
            return desconto;
        }
    }

    // Classe derivada - Eletrônico
    class Eletronico : Produto
    {
        public Eletronico(string nome, decimal preco)
            : base(nome, preco)
        {
        }

        public override decimal CalcularDesconto()
        {
            decimal desconto = Preco * 0.125m;  // 12.5% de desconto
            return desconto;
        }
    }

    class Program
    {
        static void Main()
        {
            Produto livro = new Livro("C# para Iniciantes", 300.00m);
            Produto eletronico = new Eletronico("Smartphone", 2500.00m);

            Console.WriteLine($"Produto: {livro.Nome}, Preço: R${livro.Preco}, Desconto: R${livro.CalcularDesconto()}");
            Console.WriteLine($"Produto: {eletronico.Nome}, Preço: R${eletronico.Preco}, Desconto: R${eletronico.CalcularDesconto()}");
        }
    }
}