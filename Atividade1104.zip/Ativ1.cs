﻿using System;

namespace Atividade1

{
    // Classe abstrata Pessoa
    public abstract class Pessoa
    {
        public string Nome { get; set; }
        public int Idade { get; set; }

        // Método abstrato
        public abstract void Apresentar();
    }

    // Classe Aluno que herda de Pessoa
    public class Aluno : Pessoa
    {
        public string Matricula { get; set; }

        // Implementação do método Apresentar
        public override void Apresentar()
        {
            Console.WriteLine($"Aluno: {Nome}, Idade: {Idade}, Matrícula: {Matricula}");
        }
    }

    // Classe Professor que herda de Pessoa
    public class Professor : Pessoa
    {
        public string Disciplina { get; set; }

        // Implementação do método Apresentar
        public override void Apresentar()
        {
            Console.WriteLine($"Professor: {Nome}, Idade: {Idade}, Disciplina: {Disciplina}");
        }
    }

    // Programa principal
    class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno = new Aluno
            {
                Nome = "GABRIEL",
                Idade = 21,
                Matricula = "A12345"
            };

            Professor professor = new Professor
            {
                Nome = "Ana",
                Idade = 45,
                Disciplina = "Matemática"
            };

            aluno.Apresentar();
            professor.Apresentar();
        }
    }
}
