using System;

class Livro
{
    public string Titulo;
    public string Autor;
    public int AnoPublicacao;

    public void ExibirInformacoes()
    {
        Console.WriteLine("Título: " + Titulo);
        Console.WriteLine("Autor: " + Autor);
        Console.WriteLine("Ano de Publicação: " + AnoPublicacao);
        Console.WriteLine("-----------------------------");
    }
}

class Program
{
    static void Main()
    {
        Livro livro1 = new Livro();
        Console.Write("Digite o título do livro 1: ");
        livro1.Titulo = Console.ReadLine();
        Console.Write("Digite o autor do livro 1: ");
        livro1.Autor = Console.ReadLine();
        Console.Write("Digite o ano de publicação do livro 1: ");
        livro1.AnoPublicacao = int.Parse(Console.ReadLine());

        Livro livro2 = new Livro();
        Console.Write("Digite o título do livro 2: ");
        livro2.Titulo = Console.ReadLine();
        Console.Write("Digite o autor do livro 2: ");
        livro2.Autor = Console.ReadLine();
        Console.Write("Digite o ano de publicação do livro 2: ");
        livro2.AnoPublicacao = int.Parse(Console.ReadLine());

        Livro livro3 = new Livro();
        Console.Write("Digite o título do livro 3: ");
        livro3.Titulo = Console.ReadLine();
        Console.Write("Digite o autor do livro 3: ");
        livro3.Autor = Console.ReadLine();
        Console.Write("Digite o ano de publicação do livro 3: ");
        livro3.AnoPublicacao = int.Parse(Console.ReadLine());

        Console.WriteLine("\nInformações dos livros:");
        livro1.ExibirInformacoes();
        livro2.ExibirInformacoes();
        livro3.ExibirInformacoes();
    }
}
