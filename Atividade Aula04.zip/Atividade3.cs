using System;

class Carro
{
    public string Marca { get; set; }
    public string Modelo { get; set; }
    public int AnoFabricacao { get; set; }

    public void Exibir()
    {
        Console.WriteLine($"Marca: {Marca}, Modelo: {Modelo}, Ano: {AnoFabricacao}");
    }
}

class Program
{
    static void Main()
    {
        Carro carro1 = new Carro();
        Carro carro2 = new Carro();

        Console.WriteLine("Digite os dados do primeiro carro:");
        Console.Write("Marca: ");
        carro1.Marca = Console.ReadLine();
        Console.Write("Modelo: ");
        carro1.Modelo = Console.ReadLine();
        Console.Write("Ano de Fabricação: ");
        carro1.AnoFabricacao = int.Parse(Console.ReadLine());

        Console.WriteLine("\nDigite os dados do segundo carro:");
        Console.Write("Marca: ");
        carro2.Marca = Console.ReadLine();
        Console.Write("Modelo: ");
        carro2.Modelo = Console.ReadLine();
        Console.Write("Ano de Fabricação: ");
        carro2.AnoFabricacao = int.Parse(Console.ReadLine());

        Console.WriteLine("\nInformações dos carros:");
        carro1.Exibir();
        carro2.Exibir();
    }
}
