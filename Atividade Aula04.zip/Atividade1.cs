using System;

class Jogo
{
    public string Titulo { get; set; }
    public string Genero { get; set; }
    public string Plataforma { get; set; }
    public int AnoLancamento { get; set; }

    public Jogo(string titulo, string genero, string plataforma, int anoLancamento)
    {
        Titulo = titulo;
        Genero = genero;
        Plataforma = plataforma;
        AnoLancamento = anoLancamento;
    }

    public void ExibirInfo()
    {
        Console.WriteLine("\nInformações do Jogo:");
        Console.WriteLine($"Título: {Titulo}");
        Console.WriteLine($"Gênero: {Genero}");
        Console.WriteLine($"Plataforma: {Plataforma}");
        Console.WriteLine($"Ano de Lançamento: {AnoLancamento}");
    }

    static void Main()
    {
        Console.Write("Digite o título do jogo: ");
        string titulo = Console.ReadLine();

        Console.Write("Digite o gênero do jogo: ");
        string genero = Console.ReadLine();

        Console.Write("Digite a plataforma (PC, Xbox, PlayStation, etc.): ");
        string plataforma = Console.ReadLine();

        Console.Write("Digite o ano de lançamento: ");
        int anoLancamento = int.Parse(Console.ReadLine());

        Jogo jogo = new Jogo(titulo, genero, plataforma, anoLancamento);
        jogo.ExibirInfo();
    }
}
