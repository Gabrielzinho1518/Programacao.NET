package com.example.restaurante;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;

public class ClienteApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        
        URL fxmlLocation = getClass().getResource("views/cliente_dashboard.fxml");
        System.out.println("FXML Location: " + fxmlLocation);
        
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("views/cliente_dashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
        scene.getStylesheets().add(getClass().getResource("styles/cliente_dashboard.css").toExternalForm());

        stage.setTitle("Dashboard Cliente");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
