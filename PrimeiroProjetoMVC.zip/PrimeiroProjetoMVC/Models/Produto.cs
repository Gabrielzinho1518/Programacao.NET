﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace PrimeiroProjetoMVC.Models
{
    public class Produto
    {
        [Key]
        public DbSet<Produto> Produtos { get; set; } = null!;

        public int Id { get; set; }

        [Required(ErrorMessage = "O nome do produto é obrigatório")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O preço do produto é obrigatório")]
        [Range(0.01, 9999.99, ErrorMessage = "O preço deve estar entre R$0,01 e R$9.999,99")]
        public decimal Preco { get; set; }
    }
}
