﻿using Microsoft.EntityFrameworkCore;
using PrimeiroProjetoMVC.Views.Home;

namespace PrimeiroProjetoMVC.DAL
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto> options) : base(options) {
        
        }

        public DbSet<Produto> Produtos { get; set; }
    }
}
