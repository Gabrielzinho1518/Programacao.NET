﻿using Microsoft.EntityFrameworkCore;
using PrimeiroProjetoMVC.Models;

namespace PrimeiroProjetoMVC.DAL
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto> options) : base(options)
        {
        }

        // DbSet para a entidade Produto
        public DbSet<Produto> Produtos { get; set; }
    }
}
