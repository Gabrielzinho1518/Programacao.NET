﻿namespace PrimeiroProjetoMVC.DAL
{
    public class DBContext
    {
    }
}