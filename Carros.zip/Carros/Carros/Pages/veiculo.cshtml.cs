using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Pages
{
    public class VeiculoModel : PageModel
    {
        public List<Veiculo> Veiculos { get; set; } = new List<Veiculo>();


        public void OnGet()
        {
            Veiculos = new List<Veiculo>
            {
                new Veiculo {
                    Nome = "Fiesta",
                    Modelo = "SE 1.6",
                    Marca = "Ford",
                    Renavam = "12345678900",
                    AnoFabricacao = 2018,
                    AnoModelo = 2019,
                    FotoUrl = "/images/fiesta.png"
                },
                new Veiculo {
                    Nome = "Civic",
                    Modelo = "EXL",
                    Marca = "Honda",
                    Renavam = "98765432100",
                    AnoFabricacao = 2020,
                    AnoModelo = 2021,
                    FotoUrl = "civic.png"
                }
            };
        }
    }
}
