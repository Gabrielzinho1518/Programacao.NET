using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Carros.Pages.Veiculos
{
    public class CriarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
