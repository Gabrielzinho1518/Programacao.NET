﻿public class VeiculoService
{
    private const string CaminhoArquivo = "Veiculos/App_Data/VeiculoService.txt";

    public List<Veiculo> Carregar()
    {
        var lista = new List<Veiculo>();
        if (!File.Exists(CaminhoArquivo)) return lista;

        foreach (var linha in File.ReadAllLines(CaminhoArquivo))
        {
            var partes = linha.Split(';');
            if (partes.Length < 6) continue;

            lista.Add(new Veiculo
            {
                Nome = partes[0],
                Modelo = partes[1],
                Marca = partes[2],
                Renavam = partes[3],
                AnoFabricacao = int.Parse(partes[4]),
                AnoModelo = int.Parse(partes[5]),
                FotoUrl = partes.Length > 6 ? partes[6] : null
            });
        }
        return lista;
    }

    public void Salvar(List<Veiculo> veiculos)
    {
        var linhas = veiculos.Select(v =>
            $"{v.Nome};{v.Modelo};{v.Marca};{v.Renavam};{v.AnoFabricacao};{v.AnoModelo};{v.FotoUrl}");
        File.WriteAllLines(CaminhoArquivo, linhas);
    }
}
