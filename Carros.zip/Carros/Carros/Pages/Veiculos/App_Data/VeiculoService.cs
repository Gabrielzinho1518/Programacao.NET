﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Carros.Pages.Veiculos.App_Data
{
    public class VeiculoService
    {
        private readonly string _caminhoArquivo = "Pages/veiculos/App_Data/veiculoService.txt";

        public List<Veiculo> ObterTodos()
        {
            if (!File.Exists(_caminhoArquivo)) return new List<Veiculo>();

            var linhas = File.ReadAllLines(_caminhoArquivo)
                .Where(l => !string.IsNullOrWhiteSpace(l));

            var veiculos = new List<Veiculo>();

            foreach (var linha in linhas)
            {
                var p = linha.Split(';');
                if (p.Length < 6) continue; // ignora linhas inválidas

                var veiculo = new Veiculo
                {
                    Nome = p[0],
                    Modelo = p[1],
                    Marca = p[2],
                    Renavam = p[3],
                    AnoFabricacao = int.TryParse(p[4], out int af) ? af : 0,
                    AnoModelo = int.TryParse(p[5], out int am) ? am : 0,
                    FotoUrl = p.Length > 6 ? p[6] : null
                };

                veiculos.Add(veiculo);
            }

            return veiculos;
        }


        public void Adicionar(Veiculo veiculo)
        {
            var linha = $"{veiculo.Nome};{veiculo.Modelo};{veiculo.Marca};{veiculo.Renavam};{veiculo.AnoFabricacao};{veiculo.AnoModelo};{veiculo.FotoUrl}";
            File.AppendAllText(_caminhoArquivo, linha + "\n");
        }

        public void Atualizar(List<Veiculo> veiculos)
        {
            var linhas = veiculos.Select(v => $"{v.Nome};{v.Modelo};{v.Marca};{v.Renavam};{v.AnoFabricacao};{v.AnoModelo};{v.FotoUrl}");
            File.WriteAllLines(_caminhoArquivo, linhas);
        }
    }
}
