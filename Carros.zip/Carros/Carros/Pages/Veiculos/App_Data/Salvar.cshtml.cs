using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Carros.Pages.Veiculos
{
    public class SalvarModel : PageModel
    {
        public void OnGet()
        {
            // C�digo para GET
        }

        public void OnPost()
        {
            // C�digo para POST, se necess�rio
        }
    }
}
