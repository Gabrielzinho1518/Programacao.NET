using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Carros.Pages.Veiculos.App_Data
{
    public class SalvarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
