using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Carros.Pages.Veiculos
{
    public class EditarModel : PageModel
    {
        private readonly string caminhoArquivo = "App_Data/veiculos.txt";

        [BindProperty]
        public Veiculo Veiculo { get; set; }

        public IActionResult OnGet(int id)
        {
            var veiculos = LerVeiculosDoArquivo();
            Veiculo = veiculos.FirstOrDefault(v => v.Id == id);

            if (Veiculo == null)
            {
                return NotFound();
            }

            return Page();
        }

        public IActionResult OnPost()
        {
            var veiculos = LerVeiculosDoArquivo();
            var index = veiculos.FindIndex(v => v.Id == Veiculo.Id);

            if (index == -1)
                return NotFound();

            veiculos[index] = Veiculo;
            SalvarVeiculosNoArquivo(veiculos);

            return RedirectToPage("/Veiculos/Index");
        }

        private List<Veiculo> LerVeiculosDoArquivo()
        {
            var lista = new List<Veiculo>();
            if (!System.IO.File.Exists(caminhoArquivo))
                return lista;

            foreach (var linha in System.IO.File.ReadAllLines(caminhoArquivo))
            {
                var partes = linha.Split(';');
                if (partes.Length >= 4)
                {
                    lista.Add(new Veiculo
                    {
                        Id = int.Parse(partes[0]),
                        Modelo = partes[1],
                        Marca = partes[2],
                        AnoFabricacao = int.Parse(partes[3]),
                        Imagem = partes.Length > 4 ? partes[4] : null
                    });
                }
            }

            return lista;
        }

        private void SalvarVeiculosNoArquivo(List<Veiculo> veiculos)
        {
            var linhas = veiculos.Select(v =>
                $"{v.Id};{v.Modelo};{v.Marca};{v.AnoFabricacao};{v.Imagem}");

            System.IO.File.WriteAllLines(caminhoArquivo, linhas);
        }
    }
}
