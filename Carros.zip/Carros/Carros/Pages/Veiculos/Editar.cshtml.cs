using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Carros.Pages.Veiculos
{
    public class EditarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
