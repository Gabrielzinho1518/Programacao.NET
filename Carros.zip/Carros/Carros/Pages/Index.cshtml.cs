﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Carros.Pages.Veiculos.App_Data;

namespace Carros.Pages
{
    public class IndexModel : PageModel
    {
        public List<Veiculo> Veiculos { get; set; } = new();

        [BindProperty]
        public Veiculo NovoVeiculo { get; set; } = new();

        public void OnGet()
        {
            var service = new VeiculoService();
            Veiculos = service.ObterTodos();


        }

        public IActionResult OnPost()
        {
            var service = new VeiculoService();
            var veiculos = service.ObterTodos(); 

            veiculos.Add(NovoVeiculo);

            service.Atualizar(veiculos);

            return RedirectToPage(); // recarrega a página
        }
    }
}
