﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;

public class IndexModel : PageModel
{
    public List<Veiculo> Veiculos { get; set; } = new();
    [BindProperty] public Veiculo NovoVeiculo { get; set; } = new();

    public void OnGet()
    {
        Veiculos = new VeiculoService().Carregar();
    }

    public IActionResult OnPost()
    {
        var service = new VeiculoService();
        var veiculos = service.Carregar();
        veiculos.Add(NovoVeiculo);
        service.Salvar(veiculos);
        return RedirectToPage(); // Recarrega a página
    }
}
